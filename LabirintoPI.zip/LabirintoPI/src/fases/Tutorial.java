package fases;

public class Tutorial {
    public static void main() {
        System.out.println("---------------");
        System.out.println("Bem vindo(a/e) ao tutorial!");
        System.out.println("Neste jogo você está preso em um labirinto!");
        System.out.println("Pense nisso como um jogo da velha:");
        System.out.println(" X |   |  ");
        System.out.println(" X |   | X ");
        System.out.println(" @ |   | X ");


        System.out.println("O pequeno x é você");
        System.out.println("Durante o jogo você poderá se movimentar em uma das quatro direções");
        System.out.println("E assim deve achar o final do labirinto, neste caso representado pelo o");
        System.out.println("------------------------------------------------------------------------");
        System.out.println("Neste caso, você deve ir para a direita, para cima duas vezes e depois para a direita de novo");
        System.out.println("------------------------------------------------------------------------");
        System.out.println("Durante as fases você será surpreendido por charadas");
        System.out.println("Se acertar, você conseguirá dicas de como avançar!");
        System.out.println("Se conseguir achar o mapa da fase, ficará mais fácil de você achar o caminho");
        System.out.println("Todas as fases seguem padrões, se sua intuição for boa, não precisará aprender");
        System.out.println("Mas se for bom aprendendo, não precisará de intuição");
        System.out.println("Divirta-se");
        System.out.println("Boa sorte! :)");
    }
}

